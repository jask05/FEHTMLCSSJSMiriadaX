/**
 * Monstruo al que tenemos que destruir
 */
class Opponent extends Character {
    /**
     * @param game {Game} La instancia del juego al que pertenece el oponente
     */
    constructor (game) {
        let width = 0,
            height = 0,
            x = 0,
            y = 0,
            speed = 0,
            myImage = "",
            myImageDead = "";
        
        if(!game.isBoss) {
            height = OPPONENT_HEIGHT * game.width / 50,
            width = OPPONENT_WIDTH * game.width / 50,
            x = getRandomNumber(game.width - width / 2),
            y = 0,
            speed = OPPONENT_SPEED,
            myImage = OPPONENT_PICTURE,
            myImageDead = OPPONENT_PICTURE_DEAD;
        }else{
            height = BOSS_HEIGHT * game.width / 50,
            width = BOSS_WIDTH * game.width / 50,
            x = getRandomNumber(game.width - width / 2),
            y = 0,
            speed = BOSS_SPEED,
            myImage = BOSS_PICTURE,
            myImageDead = BOSS_PICTURE_DEAD;
        }
            

        super(game, width, height, x, y, speed, myImage, myImageDead);
        this.direction = "R"; // Dirección hacia la que se mueve el oponente
        setTimeout(() => this.shoot(), 1000 + getRandomNumber(2500));
    }

    /**
     * Crea un nuevo disparo
     */
    shoot () {
        if (!this.dead && !this.game.ended) {
            if (!this.game.paused) {
                this.game.shoot(this);
            }
            setTimeout(() => this.shoot(), 1000 + getRandomNumber(2500));
        }
    }

    /**
     * Actualiza los atributos de posición del oponente
     */
    update () {
        if (!this.dead && !this.game.ended) {
            this.y += this.speed;
            if (this.y > this.game.height) {
                this.y = 0;
            }
            if (this.direction === "R") { // Hacia la derecha
                if (this.x < this.game.width - this.width - this.speed) {
                    this.x += this.speed;
                } else {
                    this.horizontalMov = 0;
                }
            } else if (this.x > this.speed) {
                this.x -= this.speed;
            } else {
                this.horizontalMov = 0;
            }
            this.horizontalMov -= this.speed;
            if (this.horizontalMov < this.speed) {
                this.horizontalMov = getRandomNumber(this.game.width / 2);
                this.direction = this.direction === "R" ? "L" : "R"; // Cambia de sentido
            }
        }
    }

    /**
     * Mata al oponente
     */
    collide() {
        if (!this.dead) {
            this.game.score += 1; // Suma +1 cada vez que muere el malo.
            document.getElementById("scoreli").innerHTML = `Score ${this.game.score}`;
            game.deadBoss = game.isBoss || false
            if(game.deadBoss){
                setTimeout(() => {
                    game.endGame();
                    this.game.removeOpponent();
                }, 2000);
                super.collide();
            }else{
                setTimeout(() => {
                    this.game.removeOpponent();
                }, 2000);
                super.collide();
            }
        }

    }
}