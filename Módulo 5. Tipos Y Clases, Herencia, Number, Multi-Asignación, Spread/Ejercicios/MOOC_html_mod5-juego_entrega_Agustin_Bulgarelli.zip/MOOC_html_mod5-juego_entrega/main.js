const OPPONENT_HEIGHT = 5,
    BOSS_HEIGHT = 10,
    OPPONENT_PICTURE = "assets/malo_02.png",
    OPPONENT_PICTURE_DEAD = "assets/malo_muerto_02.png",
    BOSS_PICTURE = "assets/boss.png",
    BOSS_PICTURE_DEAD = "assets/boss_muerto.png",
    OPPONENT_SPEED = 5,
    OPPONENT_WIDTH = 5,
    BOSS_SPEED = 10,
    BOSS_WIDTH = 10,
    GAME_OVER_PICTURE = "assets/game_over.png",
    YOU_WIN_PICTURE = "assets/you_win_02.png",
    KEY_LEFT = "LEFT",
    KEY_RIGHT = "RIGHT",
    KEY_SHOOT = "SHOOT",
    MIN_TOUCHMOVE = 20,
    PLAYER_HEIGHT = 5,
    PLAYER_PICTURE = "assets/bueno_02.png",
    PLAYER_PICTURE_DEAD = "assets/bueno_muerto_02.png",
    PLAYER_SPEED = 20,
    PLAYER_WIDTH = 5,
    SHOT_HEIGHT = 1.5,
    SHOT_SPEED = 20,
    SHOT_PICTURE_PLAYER = "assets/shot1_new.png",
    SHOT_PICTURE_OPPONENT = "assets/shot2_new.png",
    SHOT_WIDTH = 1.5,
    DEFAULTLIFES = 3,    // Vidas
    HEART_RED = "assets/heart_red.png",
    HEART_BLACK = "assets/heart_white.png";

function getRandomNumber (range) {
    return Math.floor(Math.random() * range);
}

function collision (div1, div2) {
    const a = div1.getBoundingClientRect(),
        b = div2.getBoundingClientRect();
    return !(a.bottom < b.top || a.top > b.bottom || a.right < b.left || a.left > b.right);

}

function getLives(lives) {
    let x = 1
    let printLives = document.getElementById("livesli");
    printLives.innerHTML = "Lives ";
    while (x <= lives) {
        printLives.innerHTML += `<img src="${HEART_RED}" alt="Vida ${x}" />`;
        x += 1;
    }
    if( lives === 0 ) {
        printLives.innerHTML = `Lives <img src="${HEART_BLACK}" alt="Ya no te quedan más vidas" />`;
    }
    return printLives;
    // return document.getElementById("livesli").innerHTML = `Lives: ${lives}`;
}

var game;
document.addEventListener("DOMContentLoaded", () => {
        game = new Game();
        game.start();
    }
);