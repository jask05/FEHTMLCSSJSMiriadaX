document.body.addEventListener('click', function (ev) {
    document.querySelector('.whatsapp').classList.toggle('reveal');
});


